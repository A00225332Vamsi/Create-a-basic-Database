﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDBFirst
{
    public class Regions
    {
        public Regions()
        {
            this.Territori = new HashSet<Territories>();
        }
        [Key]
        public int RegionlD { get; set; }
        public string RegionDescription { get; set; }
        public virtual ICollection<Territories> Territori { get; set; }
    }
}
