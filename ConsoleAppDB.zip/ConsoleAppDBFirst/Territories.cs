﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDBFirst
{
    public class Territories
    {
        public Territories()
        {
            this.EmployeeTerritori = new HashSet<EmployeeTerritories>();
        }
        [Key]
        public int TerritorylD { get; set; }
        public string TerritoryDescription { get; set; }
        public int RegionlD { get; set; }
        public virtual Regions Region { get; set; }

        public virtual ICollection<EmployeeTerritories> EmployeeTerritori { get; set; }
    }
}
