﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDBFirst
{
    class Program
    {
        static void Main(string[] args)
        {
            Context _context = new Context();

            List<Categories> categories = new List<Categories>()
                {
                    new Categories() {CategoryName = "Laptop",Description="",Picture=""},
                    new Categories() {CategoryName = "Mouse",Description="",Picture=""},
                    new Categories() {CategoryName = "Keyboard",Description="",Picture=""},
                    new Categories() {CategoryName = "Projector",Description="",Picture=""},
                    new Categories() {CategoryName = "HHD",Description="",Picture=""}
                };

            List<Suppliers> suppliers = new List<Suppliers>()
                {
                    new Suppliers() {Address = "305,Cal,CA-395888",City="Cal",CompanyName="Company A",ContactName="James Smith",ContactTitle="",Country="CA",Fax="",HomePage="",Phone="987987987",PostalCode="395655",Region="CA"},
                    new Suppliers() {Address = "306,Cal,CA-395898",City="Cal",CompanyName="Company B",ContactName="James A",ContactTitle="",Country="CA",Fax="",HomePage="",Phone="987987987",PostalCode="395655",Region="CA"},
                    new Suppliers() {Address = "307,Cal,CA-395818",City="Cal",CompanyName="Company C",ContactName="James B",ContactTitle="",Country="CA",Fax="",HomePage="",Phone="987987987",PostalCode="395655",Region="CA"},
                    new Suppliers() {Address = "308,Cal,CA-395822",City="Cal",CompanyName="Company D",ContactName="James C",ContactTitle="",Country="CA",Fax="",HomePage="",Phone="987987987",PostalCode="395655",Region="CA"},
                    new Suppliers() {Address = "309,Cal,CA-395874", City = "Cal", CompanyName = "Company E", ContactName = "James D", ContactTitle = "", Country = "CA", Fax = "", HomePage = "", Phone = "987987987", PostalCode = "395655", Region = "CA" }
                };

            _context.Suppliers.AddRange(suppliers);
            _context.Categories.AddRange(categories);
            _context.SaveChanges();
            Console.WriteLine("suppliers");
            Console.WriteLine("categories");

            List<Products> products = new List<Products>()
                {
                    new Products() {CategorylD = 1,Discontinued=false,ProductName="Lenovo",QuantityPerLabel="5",SupplierlD=1,UnitPrice=5000,UnitsOnOrder=1,UnitslnStock=1,ReorderLevel=5},
                    new Products() {CategorylD = 2,Discontinued=false,ProductName="Logotech",QuantityPerLabel="5",SupplierlD=1,UnitPrice=5000,UnitsOnOrder=1,UnitslnStock=1,ReorderLevel=5},
                    new Products() {CategorylD = 3,Discontinued=false,ProductName="Logotech Keyboard",QuantityPerLabel="5",SupplierlD=1,UnitPrice=5000,UnitsOnOrder=1,UnitslnStock=1,ReorderLevel=5},
                    new Products() {CategorylD = 4,Discontinued=false,ProductName="Projector",QuantityPerLabel="5",SupplierlD=1,UnitPrice=5000,UnitsOnOrder=1,UnitslnStock=1,ReorderLevel=5},
                    new Products() {CategorylD = 5,Discontinued=false,ProductName="Saga",QuantityPerLabel="5",SupplierlD=1,UnitPrice=5000,UnitsOnOrder=1,UnitslnStock=1,ReorderLevel=5}
                };

            List<Customers> customers = new List<Customers>()
                {
                    new Customers() {ContactName="James Smith",City="Cal",CompanyName="Apple",Fax="",Address="306,Cal,CA-395898",Phone="987987999",PostalCode="395656",Region="CA",ContactTitle="Jems Smith",Country="CA"},
                    new Customers() {ContactName="Peter Smith",City="Cal",CompanyName="Motorola",Fax="",Address="307,Cal,CA-395898",Phone="987987997",PostalCode="395657",Region="CA",ContactTitle="Peter Smith",Country="CA"},
                    new Customers() {ContactName="Math Peter",City="Cal",CompanyName="Lenovo",Fax="",Address="308,Cal,CA-395898",Phone="987987989",PostalCode="395655",Region="CA",ContactTitle="Math Peter",Country="CA"},
                    new Customers() {ContactName="Palekar Smith",City="Cal",CompanyName="Dell",Fax="",Address="309,Cal,CA-395898",Phone="987987957",PostalCode="395654",Region="CA",ContactTitle="Palekar Smith",Country="CA"},
                    new Customers() {ContactName="James Smith",City="Cal",CompanyName="HCL",Fax="",Address="301,Cal,CA-395898",Phone="987987985",PostalCode="395652",Region="CA",ContactTitle="Tokes Peter",Country="CA"},
                };

            _context.Products.AddRange(products);
            _context.Customers.AddRange(customers);
            _context.SaveChanges();
            Console.WriteLine("products");
            Console.WriteLine("customers");

            List<Employees> employee = new List<Employees>()
                {
                    new Employees() {Birthdate=DateTime.Now.AddYears(-25),City="Cal",FirstName="James",LastName="Smith", Address="306,Cal,CA-395898",HomePhone="987987991",PostalCode="395656",Region="CA",Photo="",Country="CA",HireDate=DateTime.Now,Title="JS",TitleOfCourtesy="TOC"},
                    new Employees() {Birthdate=DateTime.Now.AddYears(-20),City="Cal",FirstName="James1",LastName="Smith1", Address="306,Cal,CA-395891",HomePhone="987987992",PostalCode="395656",Region="CA",Photo="",Country="CA",HireDate=DateTime.Now,Title="JS",TitleOfCourtesy="TOC"},
                    new Employees() {Birthdate=DateTime.Now.AddYears(-30),City="Cal",FirstName="James2",LastName="Smith2", Address="306,Cal,CA-395892",HomePhone="987987993",PostalCode="395656",Region="CA",Photo="",Country="CA",HireDate=DateTime.Now,Title="JS",TitleOfCourtesy="TOC"},
                    new Employees() {Birthdate=DateTime.Now.AddYears(-26),City="Cal",FirstName="James3",LastName="Smith3", Address="306,Cal,CA-395893",HomePhone="987987994",PostalCode="395656",Region="CA",Photo="",Country="CA",HireDate=DateTime.Now,Title="JS",TitleOfCourtesy="TOC"},
                    new Employees() {Birthdate=DateTime.Now.AddYears(-32),City="Cal",FirstName="James4",LastName="Smith4", Address="306,Cal,CA-395894",HomePhone="987987955",PostalCode="395656",Region="CA",Photo="",Country="CA",HireDate=DateTime.Now,Title="JS",TitleOfCourtesy="TOC"},
                };

            List<Shippers> shipper = new List<Shippers>()
                {
                    new Shippers() {companyName="Blue Dart",phone="9876543211"},
                    new Shippers() {companyName="HHC",phone="5454543211"},

                };

            List<Regions> regions = new List<Regions>()
                {
                    new Regions() {RegionDescription="CA"},
                    new Regions() {RegionDescription="IN",},

                };

            _context.Employees.AddRange(employee);
            _context.Shippers.AddRange(shipper);
            _context.Regions.AddRange(regions);
            _context.SaveChanges();
            Console.WriteLine("employee");
            Console.WriteLine("shipper");
            Console.WriteLine("regions");

            List<Territories> territories = new List<Territories>()
                {
                    new Territories() {RegionlD=1,TerritoryDescription="CA"},
                    new Territories()  {RegionlD=2,TerritoryDescription="IN"}
                };
            _context.Territories.AddRange(territories);
            _context.SaveChanges();
            Console.WriteLine("territories");

            List<EmployeeTerritories> employeeTerritories = new List<EmployeeTerritories>()
                {
                    new EmployeeTerritories() {EmployeelD=1,TerritorylD=1},
                    new EmployeeTerritories() {EmployeelD=2,TerritorylD=2}
                };
            _context.EmployeeTerritories.AddRange(employeeTerritories);
            _context.SaveChanges();
            Console.WriteLine("employeeTerritories");

            List<Orders> orders = new List<Orders>()
                {
                    new Orders() {EmployeelD=1,CustomerlD=1,Freight="2.5",RequiredDate=DateTime.Now,ShipAddress="202,California,CA",ShipCity="California",ShipName="Smith",ShipperlD=1,OrderDate=DateTime.Now,ShipRegion="CA",ShipVia="BD",ShippedDate=DateTime.Now,ShipPostalCode="31245",ShipCountry="CA"},
                    new Orders() {EmployeelD=2,CustomerlD=1,Freight="3.5",RequiredDate=DateTime.Now,ShipAddress="203,California,CA",ShipCity="Torento",ShipName="Smith",ShipperlD=2,OrderDate=DateTime.Now,ShipRegion="CA",ShipVia="BD",ShippedDate=DateTime.Now,ShipPostalCode="31245",ShipCountry="CA"},
                    new Orders() {EmployeelD=3,CustomerlD=1,Freight="4",RequiredDate=DateTime.Now,ShipAddress="204,California,CA",ShipCity="London",ShipName="Smith",ShipperlD=1,OrderDate=DateTime.Now,ShipRegion="CA",ShipVia="BD",ShippedDate=DateTime.Now,ShipPostalCode="31245",ShipCountry="CA"},
                    new Orders() {EmployeelD=4,CustomerlD=1,Freight="75",RequiredDate=DateTime.Now,ShipAddress="205,California,CA",ShipCity="California",ShipName="Smith",ShipperlD=1,OrderDate=DateTime.Now,ShipRegion="CA",ShipVia="BD",ShippedDate=DateTime.Now,ShipPostalCode="31245",ShipCountry="CA"},
                    new Orders() {EmployeelD=5,CustomerlD=1,Freight="6",RequiredDate=DateTime.Now,ShipAddress="206,California,CA",ShipCity="California",ShipName="Smith",ShipperlD=1,OrderDate=DateTime.Now,ShipRegion="CA",ShipVia="BD",ShippedDate=DateTime.Now,ShipPostalCode="31245",ShipCountry="CA"},
                };
            _context.Orders.AddRange(orders);
            _context.SaveChanges();
            Console.WriteLine("orders");

            List<OrderDetails> orderDetails = new List<OrderDetails>()
                {
                    new OrderDetails() {OrderlD=1,Discount=0,ProductID=1,Quantity=2,UnitPrice=25},
                    new OrderDetails() {OrderlD=2,Discount=0,ProductID=1,Quantity=2,UnitPrice=24},
                    new OrderDetails() {OrderlD=3,Discount=0,ProductID=1,Quantity=2,UnitPrice=200},
                    new OrderDetails() {OrderlD=4,Discount=0,ProductID=1,Quantity=2,UnitPrice=350},
                    new OrderDetails() {OrderlD=5,Discount=10,ProductID=1,Quantity=2,UnitPrice=800}
                };
            _context.OrderDetails.AddRange(orderDetails);
            _context.SaveChanges();
            Console.WriteLine("orderDetails");

        }
    }
}
