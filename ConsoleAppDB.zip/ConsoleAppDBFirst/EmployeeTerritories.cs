﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDBFirst
{
    public class EmployeeTerritories
    {
        [Key]
        public int EmployeeTerritoriID { get; set; }
        public int EmployeelD { get; set; }
        public int TerritorylD { get; set; }
        public virtual Employees Employye { get; set; }
        public virtual Territories Territori { get; set; }

    }
}
