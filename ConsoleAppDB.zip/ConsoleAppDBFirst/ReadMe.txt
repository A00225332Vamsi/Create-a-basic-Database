﻿Install-Package EntityFramework
Enable-Migrations
Add-Migration Initial
Update-Database -Force