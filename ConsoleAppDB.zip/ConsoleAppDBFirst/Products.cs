﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppDBFirst
{
    public class Products
    {
        public Products()
        {
            this.OrderDetails = new HashSet<OrderDetails>();
        }
        [Key]
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int CategorylD { get; set; }
        public int SupplierlD { get; set; }
        public string QuantityPerLabel { get; set; }
        public float UnitPrice { get; set; }
        public int UnitslnStock { get; set; }
        public int UnitsOnOrder { get; set; }
        public int ReorderLevel { get; set; }
        public bool Discontinued { get; set; }
        public Categories Category { get; set; }
        public Suppliers Supplier { get; set; }
        public virtual ICollection<OrderDetails> OrderDetails { get; set; }
    }
}
