﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace ConsoleAppDBFirst
{
    public class Shippers
    {
        public Shippers()
        {
            this.Order = new HashSet<Orders>();
        }
        [Key]
        public int shipperlD { get; set; }
        public string companyName { get; set; }
        public string phone { get; set; }
        public virtual ICollection<Orders> Order { get; set; }

    }
}
