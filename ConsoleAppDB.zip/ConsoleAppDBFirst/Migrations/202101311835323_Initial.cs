﻿namespace ConsoleAppDBFirst.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Categories",
                c => new
                    {
                        CategorylD = c.Int(nullable: false, identity: true),
                        CategoryName = c.String(),
                        Description = c.String(),
                        Picture = c.String(),
                    })
                .PrimaryKey(t => t.CategorylD);
            
            CreateTable(
                "dbo.Products",
                c => new
                    {
                        ProductID = c.Int(nullable: false, identity: true),
                        ProductName = c.String(),
                        CategorylD = c.Int(nullable: false),
                        SupplierlD = c.Int(nullable: false),
                        QuantityPerLabel = c.String(),
                        UnitPrice = c.Single(nullable: false),
                        UnitslnStock = c.Int(nullable: false),
                        UnitsOnOrder = c.Int(nullable: false),
                        ReorderLevel = c.Int(nullable: false),
                        Discontinued = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.ProductID)
                .ForeignKey("dbo.Categories", t => t.CategorylD, cascadeDelete: true)
                .ForeignKey("dbo.Suppliers", t => t.SupplierlD, cascadeDelete: true)
                .Index(t => t.CategorylD)
                .Index(t => t.SupplierlD);
            
            CreateTable(
                "dbo.OrderDetails",
                c => new
                    {
                        OrderDetailID = c.Int(nullable: false, identity: true),
                        OrderlD = c.Int(nullable: false),
                        ProductID = c.Int(nullable: false),
                        UnitPrice = c.Single(nullable: false),
                        Quantity = c.Int(nullable: false),
                        Discount = c.Single(nullable: false),
                    })
                .PrimaryKey(t => t.OrderDetailID)
                .ForeignKey("dbo.Orders", t => t.OrderlD, cascadeDelete: true)
                .ForeignKey("dbo.Products", t => t.ProductID, cascadeDelete: true)
                .Index(t => t.OrderlD)
                .Index(t => t.ProductID);
            
            CreateTable(
                "dbo.Orders",
                c => new
                    {
                        OrderlD = c.Int(nullable: false, identity: true),
                        CustomerlD = c.Int(nullable: false),
                        EmployeelD = c.Int(nullable: false),
                        ShipperlD = c.Int(nullable: false),
                        OrderDate = c.DateTime(nullable: false),
                        RequiredDate = c.DateTime(nullable: false),
                        ShippedDate = c.DateTime(nullable: false),
                        ShipVia = c.String(),
                        Freight = c.String(),
                        ShipName = c.String(),
                        ShipAddress = c.String(),
                        ShipCity = c.String(),
                        ShipRegion = c.String(),
                        ShipPostalCode = c.String(),
                        ShipCountry = c.String(),
                        Employyee_EmployyeeID = c.Int(),
                    })
                .PrimaryKey(t => t.OrderlD)
                .ForeignKey("dbo.Customers", t => t.CustomerlD, cascadeDelete: true)
                .ForeignKey("dbo.Employees", t => t.Employyee_EmployyeeID)
                .ForeignKey("dbo.Shippers", t => t.ShipperlD, cascadeDelete: true)
                .Index(t => t.CustomerlD)
                .Index(t => t.ShipperlD)
                .Index(t => t.Employyee_EmployyeeID);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        CustomerlD = c.Int(nullable: false, identity: true),
                        CompanyName = c.String(),
                        ContactName = c.String(),
                        ContactTitle = c.String(),
                        Address = c.String(),
                        City = c.String(),
                        Region = c.String(),
                        PostalCode = c.String(),
                        Country = c.String(),
                        Phone = c.String(),
                        Fax = c.String(),
                    })
                .PrimaryKey(t => t.CustomerlD);
            
            CreateTable(
                "dbo.Employees",
                c => new
                    {
                        EmployyeeID = c.Int(nullable: false, identity: true),
                        LastName = c.String(),
                        FirstName = c.String(),
                        Title = c.String(),
                        TitleOfCourtesy = c.String(),
                        Birthdate = c.String(),
                        HireDate = c.String(),
                        Address = c.String(),
                        City = c.String(),
                        Region = c.String(),
                        PostalCode = c.String(),
                        Country = c.String(),
                        HomePhone = c.String(),
                        Extension = c.String(),
                        Photo = c.String(),
                        Notes = c.String(),
                        ReportsTo = c.String(),
                        PhotoPath = c.String(),
                    })
                .PrimaryKey(t => t.EmployyeeID);
            
            CreateTable(
                "dbo.EmployeeTerritories",
                c => new
                    {
                        EmployeeTerritoriID = c.Int(nullable: false, identity: true),
                        EmployeelD = c.Int(nullable: false),
                        TerritorylD = c.Int(nullable: false),
                        Employye_EmployyeeID = c.Int(),
                    })
                .PrimaryKey(t => t.EmployeeTerritoriID)
                .ForeignKey("dbo.Employees", t => t.Employye_EmployyeeID)
                .ForeignKey("dbo.Territories", t => t.TerritorylD, cascadeDelete: true)
                .Index(t => t.TerritorylD)
                .Index(t => t.Employye_EmployyeeID);
            
            CreateTable(
                "dbo.Territories",
                c => new
                    {
                        TerritorylD = c.Int(nullable: false, identity: true),
                        TerritoryDescription = c.String(),
                        RegionlD = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.TerritorylD)
                .ForeignKey("dbo.Regions", t => t.RegionlD, cascadeDelete: true)
                .Index(t => t.RegionlD);
            
            CreateTable(
                "dbo.Regions",
                c => new
                    {
                        RegionlD = c.Int(nullable: false, identity: true),
                        RegionDescription = c.String(),
                    })
                .PrimaryKey(t => t.RegionlD);
            
            CreateTable(
                "dbo.Shippers",
                c => new
                    {
                        shipperlD = c.Int(nullable: false, identity: true),
                        companyName = c.String(),
                        phone = c.String(),
                    })
                .PrimaryKey(t => t.shipperlD);
            
            CreateTable(
                "dbo.Suppliers",
                c => new
                    {
                        SupplierlD = c.Int(nullable: false, identity: true),
                        CompanyName = c.String(),
                        ContactName = c.String(),
                        ContactTitle = c.String(),
                        Address = c.String(),
                        City = c.String(),
                        Region = c.String(),
                        PostalCode = c.String(),
                        Country = c.String(),
                        Phone = c.String(),
                        Fax = c.String(),
                        HomePage = c.String(),
                    })
                .PrimaryKey(t => t.SupplierlD);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Products", "SupplierlD", "dbo.Suppliers");
            DropForeignKey("dbo.OrderDetails", "ProductID", "dbo.Products");
            DropForeignKey("dbo.Orders", "ShipperlD", "dbo.Shippers");
            DropForeignKey("dbo.OrderDetails", "OrderlD", "dbo.Orders");
            DropForeignKey("dbo.Orders", "Employyee_EmployyeeID", "dbo.Employees");
            DropForeignKey("dbo.Territories", "RegionlD", "dbo.Regions");
            DropForeignKey("dbo.EmployeeTerritories", "TerritorylD", "dbo.Territories");
            DropForeignKey("dbo.EmployeeTerritories", "Employye_EmployyeeID", "dbo.Employees");
            DropForeignKey("dbo.Orders", "CustomerlD", "dbo.Customers");
            DropForeignKey("dbo.Products", "CategorylD", "dbo.Categories");
            DropIndex("dbo.Territories", new[] { "RegionlD" });
            DropIndex("dbo.EmployeeTerritories", new[] { "Employye_EmployyeeID" });
            DropIndex("dbo.EmployeeTerritories", new[] { "TerritorylD" });
            DropIndex("dbo.Orders", new[] { "Employyee_EmployyeeID" });
            DropIndex("dbo.Orders", new[] { "ShipperlD" });
            DropIndex("dbo.Orders", new[] { "CustomerlD" });
            DropIndex("dbo.OrderDetails", new[] { "ProductID" });
            DropIndex("dbo.OrderDetails", new[] { "OrderlD" });
            DropIndex("dbo.Products", new[] { "SupplierlD" });
            DropIndex("dbo.Products", new[] { "CategorylD" });
            DropTable("dbo.Suppliers");
            DropTable("dbo.Shippers");
            DropTable("dbo.Regions");
            DropTable("dbo.Territories");
            DropTable("dbo.EmployeeTerritories");
            DropTable("dbo.Employees");
            DropTable("dbo.Customers");
            DropTable("dbo.Orders");
            DropTable("dbo.OrderDetails");
            DropTable("dbo.Products");
            DropTable("dbo.Categories");
        }
    }
}
